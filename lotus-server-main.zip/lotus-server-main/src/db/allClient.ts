import {Client} from "../model/client";

var clients: Client[] = [];
module.exports = clients;