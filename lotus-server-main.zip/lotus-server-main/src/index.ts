import { Server } from "./server";

const app = new Server().getApp();
export { app };