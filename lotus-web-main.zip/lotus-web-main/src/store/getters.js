const getters = {
  clientID: state => state.client.clientID,
  socketID: state => state.client.socketID
}
export default getters
